# RAZE — Video Editing Portfolio

A responsive, single-page portfolio website. It is plain HTML/CSS/JS and can be hosted free on GitHub Pages or Cloudflare Pages.

## Before publishing
1. Open `index.html` in a text editor.
2. Replace `YOUR_EMAIL@example.com` with the email address you want clients to use.
3. Replace each placeholder project tile/link with your actual video URL and thumbnail.
4. Update the intro/services if needed.
5. Do not present placeholder tiles as completed client work.

## Free publishing with GitHub Pages
1. Create/sign in to a GitHub account.
2. Create a new **public** repository named `raze-portfolio`.
3. Upload `index.html` to the repository's root.
4. Open **Settings → Pages**.
5. Under Build and deployment, choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
6. GitHub will provide a public `https://YOUR-USERNAME.github.io/raze-portfolio/` link after deployment.

GitHub Pages hosting is free for public repositories. A custom domain is optional and costs extra; the default GitHub URL is enough to share your portfolio.
